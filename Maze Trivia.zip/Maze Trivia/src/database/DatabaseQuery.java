package database;

import question.Question;
import question.QuestionFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Random;

public class DatabaseQuery {
    private static final Random RANDOM = new Random();

    public static void main(String[] args) {
        // Ensure the table is created
        DatabaseManager.createTable();

        // Clear the table to avoid duplicates
        clearTable();

        // Import questions to populate the table
        QuestionImporter.importQuestions("questions.txt");

        // Example usage
        System.out.println(getRandomQuestion("multipleChoice"));
        System.out.println(getRandomAnswer("trueFalse"));
        System.out.println(Arrays.toString(getRandomChoices("multipleChoice")));
    }

    private static void clearTable() {
        try (Connection connection = DatabaseManager.connect();
             Statement statement = connection.createStatement()) {

            statement.executeUpdate("DELETE FROM questions");
            System.out.println("Table cleared successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String getRandomQuestion(String type) {
        String query = "SELECT question FROM questions WHERE type = '" + type + "' ORDER BY RANDOM() LIMIT 1";
        try (Connection connection = DatabaseManager.connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                return resultSet.getString("question");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String getRandomAnswer(String type) {
        String query = "SELECT answer FROM questions WHERE type = '" + type + "' ORDER BY RANDOM() LIMIT 1";
        try (Connection connection = DatabaseManager.connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                return resultSet.getString("answer");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String[] getRandomChoices(String type) {
        String query = "SELECT choices FROM questions WHERE type = '" + type + "' ORDER BY RANDOM() LIMIT 1";
        try (Connection connection = DatabaseManager.connect();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            if (resultSet.next()) {
                String choices = resultSet.getString("choices");
                return choices.split(",");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

