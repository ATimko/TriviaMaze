package maze;

public class MazeFactory {
    public static Maze createMaze() {
        return null;
    }
}
